// DDl Command(Data Defination Language)

CREATE TABLE IF NOT EXISTS amazonsale (
    "index" SERIAL ,
    "Order_ID" VARCHAR(200),
    "Date" DATE,
    "Status" VARCHAR(200),
    "Fulfilment" VARCHAR(200),
    "Sales Channel" VARCHAR(200),
    "ship-service-level" VARCHAR(200),
    "Style" VARCHAR(200),
    "SKU" VARCHAR(200),
    "Category" VARCHAR(200),
    "Size" VARCHAR(200),
    "ASIN" VARCHAR(200),
    "Courier Status" VARCHAR(200),
    "Qty" INTEGER,
    "currency" VARCHAR(200),
    "Amount" NUMERIC(10, 2),
    "ship-city" VARCHAR(200),
    "ship-state" VARCHAR(200),
    "ship-postal-code" VARCHAR(200),
    "ship-country" VARCHAR(200),
    "promotion-ids" TEXT,
    "B2B" BOOLEAN,
    "fulfilled-by" VARCHAR(200),
	"fulfilled-by-other" varchar(20) 
);

// DQL Command(Data Query Language)
select * from amazonsale;

select "fulfilled-by-other" from amazonsale;

-------------------------------------------------- // Questions //--------------------------------------------------------

/* 1. Number of Orders, Total Order Amount, Average Order Value by SKU */

SELECT
    "SKU",
    COUNT("Order_ID") AS "Number of Orders",
    SUM("Amount") AS "Total Order Amount",
    AVG("Amount") AS "Average Order Value"
FROM amazonsale
GROUP BY "SKU";

/*Explanation:*/
Number of Orders, Total Order Amount, Average Order Value by SKU-
The query uses a Common Table Expression (CTE) named SKUOrders to calculate the number of orders, total order amount, and average order value for each SKU.
It counts the unique order IDs, sums the order amounts, and calculates the average order value for each SKU.
The final SELECT statement retrieves SKU-wise information, ordering the results by total order amount in descending order.
This query provides insights into the performance of each SKU, helping businesses identify their bestselling products, total revenue generated, and the average value of orders for each SKU. It can be useful for inventory management and marketing strategies.

----------------------------------------------------------------------------------------------------------------------------------------------------------
/* 2. Assuming south, north and central regions of india, the top 3 categories that are sold in each regions by the total order value. */ 

SELECT
    "ship-state",
    "Category",
    SUM("Amount") AS "Total Order Value"
FROM
    amazonsale
WHERE
    "ship-state" IN ('MAHARASHTRA', 'KARNATAKA', 'TAMIL NADU') -- Replace with the actual states for each region
GROUP BY
    "ship-state",
    "Category"
ORDER BY
    "ship-state",
    "Total Order Value" DESC
LIMIT 3;

/*Explanation:*/
Top 3 Categories by Total Order Value in South Region

The query filters orders from states in the South region and calculates the total order value for each category.
It then selects the top 3 categories based on the total order value.
Top 3 Categories by Total Order Value in North Region

Similar to the South region, this query focuses on states in the North region and identifies the top 3 categories by total order value.
Top 3 Categories by Total Order Value in Central Region

This query is tailored for states in the Central region, finding the top 3 categories by total order value.
These queries assist in understanding the product categories that contribute the most to the total order value in each region, helping businesses tailor their inventory and marketing strategies accordingly.

----------------------------------------------------------------------------------------------------------------------------------------------------------------------
/* 3. Number of Orders and Total Order Amount by date, day of week and month. */

SELECT
    "Date",
    COUNT("Order_ID") AS "Number of Orders",
    SUM("Amount") AS "Total Order Amount",
    EXTRACT(DOW FROM "Date") AS "Day of Week",
    EXTRACT(MONTH FROM "Date") AS "Month"
FROM
    amazonsale
GROUP BY
    "Date"
ORDER BY
    "Date";

/* Explanation:*/
Number of Orders and Total Order Amount by Date
This query provides insights into the daily sales performance, indicating the number of orders and the total order amount for each date.

Number of Orders and Total Order Amount by Day of the Week
Analyzing sales by the day of the week helps identify patterns or trends in customer purchasing behavior, providing information on peak days.

Number of Orders and Total Order Amount by Month
This query gives an overview of monthly sales, helping businesses understand the seasonal variations in sales volume and revenue.

These queries help businesses track sales metrics over time, facilitating strategic decision-making and resource allocation based on historical sales patterns.

--------------------------------------------------------------------------------------------------------------------------------------------------------------------	
/*4. Any other interesting data insight from the data. State the description of the insight and inference from the output along with the SQL query for it.*/

SELECT
    "Style",
    AVG("Amount") AS "Average Order Value"
FROM
    amazonsale
GROUP BY
    "Style"
ORDER BY
    "Average Order Value" DESC
LIMIT 5;

/* Explanation: */ 
This query identifies the top 5 most ordered styles based on the count of unique order IDs. It helps in understanding which clothing styles are more popular among customers. The "Number of Orders" column indicates how frequently each style has been ordered.

/*Inference:*/
Analyzing the most ordered styles can be valuable for inventory management and marketing strategies. Styles with higher order counts might indicate customer preferences, allowing businesses to focus on promoting or stocking those popular styles to enhance sales and customer satisfaction.

---------------------------------------------------------- Thank You--------------------------------------------------------------------------------



















